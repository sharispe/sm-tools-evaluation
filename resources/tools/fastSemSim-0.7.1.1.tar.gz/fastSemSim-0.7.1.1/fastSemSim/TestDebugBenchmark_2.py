#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
'''
Copyright 2011 Marco Mina. All rights reserved.

This file is part of fastSemSim

fastSemSim is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

fastSemSim is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with fastSemSim.  If not, see <http://www.gnu.org/licenses/>.
'''

"""
This is an example program.
It loads a Gene Ontology, an annotation corpus (in GOA GAF-2 format) and evaluate Resnik Sem Sim between all the pairs of GO Terms from BP ontology present in the annotation corpus.
"""

from fastSemSim.GO import AnnotationCorpus
from fastSemSim.GO import GeneOntology
#from fastSemSim.SemSim import TermSemSim
from SemSim import *
from SemSim.SemSimUtils import SemSimUtils 
import sys

if __name__ == "__main__":
	
	# example data
	if len(sys.argv) != 3:
		print "[O] GO XML format"
		print "[O] Annotation file plain"
		exit()
	else:
		go_file = sys.argv[1]
		ac_file = sys.argv[2]
		

	print "Loading Gene Ontology from " + str(go_file) + "..."
	ignore_part_of=True
	ignore_regulates=True
	go = GeneOntology.load_GO_XML(go_file,ignore_part_of,ignore_regulates)
	print "-> Ontology correctly loaded: " + str(go.node_num()) + " nodes and " +  str(go.edge_num()) + " edges."
	print ""

	ac = AnnotationCorpus.AnnotationCorpus(go)
	print "Loading annotation corpus from gaf-2 file " + str(ac_file) + "..."
	ac.parse(ac_file,'plain') # to parse gaf-2 / GOA files
	ac.sanitize()
	print "-> Annotation Corpus correctly loaded. Annotated terms: " + str(len(ac.reverse_annotations)) + ". Annotated proteins: " + str(len(ac.annotations)) 
	print ""

	util = SemSimUtils(ac, go)

	for n in go.nodes_edges.keys():

		print str(go.id2name(n)),
		for p in go.parents[n]:
			print "\t"+str(go.id2name(p)),
		print ""
	# GO:0097167	GO:0045054

	
