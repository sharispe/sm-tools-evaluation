### R code from vignette source 'GOSemSim.Rnw'

###################################################
### code chunk number 1: options
###################################################
options(width=60)
library(GOSemSim)
library(org.Hs.eg.db)
library(GO.db)


###################################################
### code chunk number 2: GOSemSim.Rnw:84-86
###################################################
library(GOSemSim)
help(GOSemSim)


###################################################
### code chunk number 3: function call
###################################################
goSim("GO:0004022", "GO:0005515", ont="MF", measure="Wang")
go1 = c("GO:0004022","GO:0004024","GO:0004174")
go2 = c("GO:0009055","GO:0005515")
mgoSim(go1, go2, ont="MF", measure="Wang", combine="BMA")

geneSim("241", "251", ont="MF", organism="human", measure="Wang", combine="BMA")
mgeneSim(genes=c("835", "5261","241", "994"), ont="MF", organism="human", measure="Wang")


###################################################
### code chunk number 4: clusterSim (eval = FALSE)
###################################################
## gs1 <- c("835", "5261","241", "994", "514", "533")
## gs2 <- c("578","582", "400", "409", "411")
## clusterSim(gs1, gs2, ont="MF", organism="human", measure="Wang", combine="BMA")
## 
## x <- org.Hs.egGO
## hsEG <- mappedkeys(x)
## set.seed <- 123
## clusters <- list(a=sample(hsEG, 20), b=sample(hsEG, 20), c=sample(hsEG, 20))
## mclusterSim(clusters, ont="MF", organism="human", measure="Wang", combine="BMA")


###################################################
### code chunk number 5: GOSemSim.Rnw:337-338
###################################################
sessionInfo()


